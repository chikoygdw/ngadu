<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container d-flex align-content-center justify-content-center"><br>
        <div class="col-md-4 col-md-offset-4">
            <h2 class="text-center"><b>ANIS</b><br>Aplikasi Nilai Siswa</h3>
            <hr>
            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <b>Opps!</b> <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('actionlogin')); ?>" method="post">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" required="">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password" required="">
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-lg btn-primary btn-block">Log In</button>
                </div>
                <hr>
                <p class="text-center">Belum punya akun? <a href="<?php echo e('register'); ?>">Daftar</a> sekarang!</p>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\admin\Documents\LSP RPL\PelayananPengaduanSekolah\resources\views/login.blade.php ENDPATH**/ ?>