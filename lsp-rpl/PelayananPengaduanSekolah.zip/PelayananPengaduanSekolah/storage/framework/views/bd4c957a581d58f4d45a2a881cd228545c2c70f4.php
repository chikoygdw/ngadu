

<?php $__env->startSection('container'); ?>
<div class="row justify-content-center">
    
    <div class="col-12 py-4" id="dashboard">
        <h2 class="mb-3">Dashboard Admin</h2>
    <div class="card  p-4 table-responsive">
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">No</th>
                <th scope="col">NIS</th>
                <th scope="col">Kelas</th>
                <th scope="col">Kategori</th>
                <th scope="col">Lokasi</th>
                <th scope="col">Keterangan</th>
                <th scope="col">Bukti</th>
                <th scope="col">Waktu</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $aspirasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($as->id); ?></th>
                    <td><?php echo e($as->input_aspirasi->siswa->nis); ?></td>
                    <td><?php echo e($as->input_aspirasi->siswa->kelas); ?></td>
                    <td><?php echo e($as->kategori->ket_kategori); ?></td>
                    <td><?php echo e($as->input_aspirasi->lokasi); ?></td>
                    <td><?php echo e($as->input_aspirasi->ket); ?></td>
                    <td><img src="<?php echo e(asset('storage/'.$as->input_aspirasi->bukti)); ?>" class="img-thumbnail" style="max-width: 50%; min-width: 20%;" alt=""></td>
                    <td><?php echo e($as->created_at); ?></td>
                    <td>  <?php if($as['status'] == 'Menunggu'): ?>
                        <form action="/admin/status" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="Proses">
                            <input type="hidden" name="id_aspirasi"
                                value="<?php echo e($as->id_aspirasi); ?>">
                            <button type="submit"
                                class="btn btn-primary btn-sm mb-3 w-100" onclick="return confirm('Anda yakin ingin proses pengaduan ini?')">Proses</button>
                        </form>
                    <?php elseif($as['status'] == 'Proses'): ?>
                    <form action="/admin/status" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="status" value="Selesai">
                        <input type="hidden" name="id_aspirasi"
                            value="<?php echo e($as->id_aspirasi); ?>">
                        <button type="submit"
                            class="btn btn-success btn-sm mb-3 w-100" onclick="return confirm('Anda yakin pengaduan ini udh selesai?')">Selesai</button>
                    </form>
                    <?php else: ?>
                    <button type="submit"
                    class="btn btn-secondary btn-sm mb-3 w-100" disabled>Selesai</button>
                    <?php endif; ?>
                    <form action="/admin/delete" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id_aspirasi"
                        value="<?php echo e($as->id_aspirasi); ?>">
                        <button type="submit"
                        class="btn btn-primary btn-sm mb-3 w-100"  onclick="return confirm('Anda yakin ingin menghapus pengaduan ini?')">Delete</button>
                    </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php if($aspirasi->count()): ?>
          <?php else: ?>
          <p class="text-center fs-4 mt-5">Tidak ada Aspirasi Siswa. </p>
          <?php endif; ?>
          <div class="justify-content-end d-flex">
            <?php echo e($aspirasi->links()); ?>

          </div>
    </div>
    </div>
    <div class="col-12" >
        <div class="py-3 rounded" style="background-color:  #0d9952"></div>
    </div>
    
    <div class="col-12 py-4" id="history" >
        <h2 class="mb-3">History Aspirasi</h2>
    <div class="card  p-4 table-responsive">
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">No</th>
                <th scope="col">NIS</th>
                <th scope="col">Kelas</th>
                <th scope="col">Kategori</th>
                <th scope="col">Lokasi</th>
                <th scope="col">Keterangan</th>
                <th scope="col">Bukti</th>
                <th scope="col">Waktu</th>
                <th scope="col">Ratting</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($as->id); ?></th>
                                                <td><?php echo e($as->input_aspirasi->siswa->nis); ?></td>
                                                <td><?php echo e($as->input_aspirasi->siswa->kelas); ?></td>
                                                <td><?php echo e($as->kategori->ket_kategori); ?></td>
                                                <td><?php echo e($as->input_aspirasi->lokasi); ?></td>
                                                <td><?php echo e($as->input_aspirasi->ket); ?></td>
                                                <td><img src="<?php echo e(asset('storage/'.$as->input_aspirasi->bukti)); ?>" class="img-fluid img-thumbnail" style="max-width: 50%; min-width: 20%;" alt=""></td>
                                                <td><?php echo e($as->created_at); ?></td>
                                                <td> <div class=" text-center text-warning">
                                                    <?php switch($as->feedback):
                                                        case (1): ?>
                                                        <i class="bi bi-star-fill"></i>
                                                        <br>
                                                        (<?php echo e($as->feedback); ?>)
                                                            <?php break; ?>
                                                        <?php case (2): ?>
                                                        <i class="bi bi-star-fill"></i> 
                                                        <i class="bi bi-star-fill"></i>
                                                        <br>
                                                        (<?php echo e($as->feedback); ?>)
                                                            <?php break; ?>
                                                        <?php case (3): ?>
                                                        <i class="bi bi-star-fill"></i>
                                                         <i class="bi bi-star-fill"></i>
                                                         <i class="bi bi-star-fill"></i>
                                                         <br>
                                                         (<?php echo e($as->feedback); ?>)
                                                            <?php break; ?>
                                                        <?php case (4): ?>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <br>
                                                        (<?php echo e($as->feedback); ?>)
                                                        <?php break; ?>
                                                        <?php case (5): ?>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <i class="bi bi-star-fill"></i>
                                                        <br>
                                                        (<?php echo e($as->feedback); ?>)
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                            
                                                    <?php endswitch; ?>
                                                </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php if($selesai->count()): ?>
          <?php else: ?>
          <p class="text-center fs-4 mt-5">Tidak ada Aspirasi Siswa. </p>
          <?php endif; ?>
          <div class="justify-content-end d-flex">
          <?php echo e($selesai->links()); ?>

          </div>
    </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Documents\LSP RPL\PelayananPengaduanSekolah\resources\views/Admin.blade.php ENDPATH**/ ?>